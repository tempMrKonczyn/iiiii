<?xml version="1.0" encoding="utf-8" standalone="no"?>
<Configuration MasterDeviceType="33554450">
  <TotalData>
    <Ports>
      <Port Index="1">
        <Tables>
          <Table ProtocolType="Modbus" Mode="0" AutoScan="0">
            <Blocks>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
            </Blocks>
          </Table>
        </Tables>
      </Port>
      <Port Index="2">
        <Tables>
          <Table ProtocolType="Modbus" Mode="0" AutoScan="0">
            <Blocks>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
            </Blocks>
          </Table>
        </Tables>
      </Port>
      <Port Index="3">
        <Tables>
          <Table ProtocolType="ModbusTCP" Mode="0">
            <Blocks>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
              <Block Enable="0" StationAddr="0" RemoteIP="0.0.0.0" DeviceTypeCode="281475010265089" In_Address="0" Out_Address="0" Read_Address="0" Write_Address="0" Read_Amount="256" Write_Amount="256" W_FuncCode="0" R_FuncCode="0" Interval_Time="0" TimeOut="0" AddrType="0"/>
            </Blocks>
          </Table>
        </Tables>
      </Port>
      <Port Index="4">
        <Tables>
          <Table ProtocolType="ModbusTCP" Mode="0">
            <Blocks/>
          </Table>
        </Tables>
      </Port>
      <Port Index="5">
        <Tables>
          <Table ProtocolType="Modbus" Mode="0" AutoScan="0">
            <Blocks/>
          </Table>
        </Tables>
      </Port>
      <Port Index="6">
        <Tables>
          <Table ProtocolType="Modbus" Mode="0" AutoScan="0">
            <Blocks/>
          </Table>
        </Tables>
      </Port>
    </Ports>
  </TotalData>
</Configuration>
